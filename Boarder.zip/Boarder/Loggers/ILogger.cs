﻿namespace Boarder.Loggers
{
    public interface ILogger
    {
        void Log(string  value);
    }
}
